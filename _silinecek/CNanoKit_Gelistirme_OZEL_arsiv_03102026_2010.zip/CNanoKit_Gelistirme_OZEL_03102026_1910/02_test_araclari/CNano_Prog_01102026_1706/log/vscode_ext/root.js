'use strict';

const vscode = require('vscode')
const child  = require("child_process")
const fs     = require("fs")
const os     = require("os")
const path   = require('path')
const cache  = require("./cache")
const crypto = require('crypto')


const wine_drive = os.homedir() + '/.wine/drive_c'


exports.activate = (context) =>
{
    exports.context       = context
    exports.extensionPath = context.extensionPath
    vscode.workspace.onDidChangeConfiguration(onDidChangeConfiguration)
    onDidChangeConfiguration()
    emptyFolder(exports.path.temp)
}



function onDidChangeConfiguration()
{
    const sep    = exports.sep = path.sep
    const cfg    = exports.config = vscode.workspace.getConfiguration('pos')
    const win    = exports.win = process.platform === 'win32'
    const ldr    = autoPath(cfg.main.compiler)
    const home   = os.homedir()

    const wine   = {
        cmd:   (win ? ''   : 'wine '),
        drive: (win ? 'C:' : wine_drive),
        user:  (win ? home : (wine_drive + '/users/' + home.split(/[\/\\]/).pop()))
    }
        
    const loader = path.dirname(ldr) + sep
    const pds    = path.resolve(ldr, '..' + sep + '..') + sep
    const ext    = exports.extensionPath + sep
    const user   = wine.user + sep + 'PDS' + sep

    exports.debug = cfg.x.DEBUG
    
    exports.wine = wine

    exports.path = {
        ext,
        pds,
        user,
        home,
        loader,
        include: {
            loader,
            user:   user   + 'Includes' + sep,
            main:   loader + 'Includes' + sep,
            src:    loader + 'Includes' + sep + 'Sources' + sep
        },
        web:    ext + 'web'   + sep,
        temp:   ext + 'files' + sep + 'temp' + sep,
        docs:   pds + 'PDS'   + sep + 'Docs' + sep
    }
}



exports.debugTime = (name, doc, force) =>
{
    return !exports.debug && !force
    ?
    { begin(){return this}, end(){}, start(){}, stop(){} }
    :
    {
        N:       name + (doc ? '  ' + (doc?.fileName || doc).split(/[\/\\]/).pop() : ''),
        begin()  { console.time(this.N);     return this                                                    },
        end()    { console.timeEnd(this.N);                                                                 },
        start()  { this.t0 = performance.now();                                                             },
        stop(v)  { let t1  = performance.now();    console.log(this.N, v, (t1 - this.t0).toFixed(1) + "ms") }
    }
}



exports.getMain = (doc) =>
{
    let prt;    if (typeof doc === 'object') doc = doc.fileName
    
    if (!exports.config.smartParentIncludes || path.extname(doc).toLowerCase() === '.bas') return doc
    
    while (prt = (cache.get(doc).$.parent)) doc = prt
    
    return doc
}



exports.getParent = (doc, main) =>
{
    let prt;        if (typeof doc === 'object') doc = doc.fileName
    
    while (prt = (cache.get(doc).$.parent)) main = doc = prt
    
    return main
}



exports.getCore = (doc, isAll = false) =>
{
    if (doc) { const dev = cache.get(doc).symbols.device.$;     return isAll ? dev : dev.$info?.core }
}



exports.IsAsmLst = (fName) =>
{
    if (typeof fName === 'object') fName = fName.fileName
    
    return ['.asm', '.lst'].includes(path.extname(fName || '').toLowerCase())
}



function emptyFolder(dirPath)
{
  try {
    fs.rmSync(dirPath, { recursive: true,  force: true })
    fs.mkdirSync(dirPath)
  } catch {}
}
exports.emptyFolder = emptyFolder



function readDir(value)
{
    let result = []
    
    try {    result = fs.readdirSync(value)    }catch{}
    
    return result
}
exports.readDir = readDir



function readFile(fName, def = '', ext)
{
    fName = typeof fName === 'object' ? fName.uri.fsPath : fName
    
    if (ext) fName = extFile(fName, ext)
    
    try {    return fs.readFileSync(fName, 'utf-8')    } catch {    return def    }
}
exports.readFile = readFile



function writeFile(fName, txt = '', ext)
{
    fName = typeof fName === 'object' ? fName.uri.fsPath : fName
    
    if (ext) fName = extFile(fName, ext)

    try {    fs.writeFileSync(fName, txt, 'utf-8');    return true    } catch {    return false    }
}
exports.writeFile = writeFile



function checkFile(fName)
{
    if (fs.existsSync(fName) && fs.statSync(fName).isFile())    return fName
}
exports.checkFile = checkFile



function extFile(fName, ext = '')
{
    const name = path.dirname(fName) + path.sep + path.parse(fName).name
    
    if (!Array.isArray(ext))  return name + ext
    
    for (let v of ext)    if (v = checkFile(name + v))  return v
}
exports.extFile = extFile



function JsonFromFile(fName, fnErr)
{
    try {
        const v = fs.readFileSync(fName, 'utf-8').replace(/\/\*[\s\S]*?\*\//g, '');      return JSON.parse(v)
    }
    catch (e) {  if (fnErr) fnErr(e)  }
}
exports.JsonFromFile = JsonFromFile



function JsonToFile(value, fName, fnErr)
{
    try {
        const v = JSON.stringify(value, null, '\t');      fs.writeFileSync(fName, v, 'utf-8');      return true
    }
    catch (e) {  if (fnErr) fnErr(e)  }
}
exports.JsonToFile = JsonToFile



function regex(value, flags = 'igm', sym = '|')
{
    const A = (v) => v.reduce((a,i) => a + (typeof i === 'string' ? L(i) : (Array.isArray(i) ? '(' + A(i) + ')' : (a && sym) + i.source)), '')
    
    const L = (v) => v.replace(/^[\t ]*\/\/.*$/gm, '').replace(/^[\t ]*(.*?)[\t ]*$/gm, '$1').replace(/[\r\n]/g, '')
    
    const P = value?.raw ? L(value.raw.join('')) : Array.isArray(value) ? A(value) : L(value)
    
    return flags == null ? P : new RegExp(P, flags)
}
exports.regex = regex



function limitText(txt, count = 130)
{
	return txt.slice(0, count) + (txt.length > count ? " ... SIZE = " + txt.length : "")
}
exports.limitText = limitText



function openURL(url)
{
    url = url.replace(/%20/g, ' ')
    
    return child.exec(exports.win ? `start "" "${url}"` : `xdg-open '${url}'`)
}
exports.openURL = openURL



function openDoc(url, prm = {viewColumn: vscode.ViewColumn.One})
{
    try {
        vscode.workspace.openTextDocument(vscode.Uri.file(url)).then(doc => vscode.window.showTextDocument(doc, prm))
    }catch{}
}
exports.openDoc = openDoc



function sleep(ms)
{
    return new Promise(r => setTimeout(r, ms))
}
exports.sleep = sleep



function getHash(data, alg = 'sha256', enc = 'hex')
{
    return crypto.createHash(alg).update(data).digest(enc)
}
exports.getHash = getHash



function generateUUID()
{
    let d = new Date().getTime(),   d2 = (performance && performance.now && performance.now() * 1000) || 0
    
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c =>
    {
        var r = Math.random() * 16

        if (d > 0) {
            r = (d + r)  % 16 | 0;      d  = Math.floor(d/16)
        } else {
            r = (d2 + r) % 16 | 0;      d2 = Math.floor(d2/16)
        }

        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16).toUpperCase()
    })
}
exports.generateUUID = generateUUID



function objectPath(obj, value, def)
{
	value = typeof value !== 'string' ? value : value.split(/\.|\[([^\]]+)\]/g).reduce((a,k) => (k && a.push(k), a), [])
    
    for (const i of value)
    {
        if (i in obj)   obj = obj[i]
        else            return def
    }
    
    return obj
}
exports.objectPath = objectPath;



function autoPath(fName)
{
    return exports.win ? fName.replace(/\//g, '\\') : fName.replace(/c:/ig, wine_drive).replace(/z:/ig, '').replace(/\\/g, '/')
}
exports.autoPath = autoPath



function winver(fName)
{
    if (exports.win) {  const vi = require('win-version-info');    return vi(autoPath(fName))  }
    
    let tmp = '',  ver = {}
    
    try {    tmp = fs.readFileSync(autoPath(fName), 'ucs-2')    } catch{}
    
    tmp = tmp.match(/\0StringFileInfo\0([\s\S]+?)\0VarFileInfo\0/i)
    tmp = tmp ? tmp[1].replace(/[\x00-\x1F]/g, '\0') : ''
    
    for (const v of tmp.matchAll(/([a-z]{4,})\0{1,2}([^\0]+)/ig))   ver[v[1]] = v[2]
    
    return ver
}
exports.winver = winver



async function exeIcon(fName)
{
    if (!exports.win) return

    const png = exports.path.temp + path.basename(fName) + '__' + getHash(fName) +  '.png';         if (checkFile(png)) return png

    try {
        const res = await new PS().icon(fName, png);            if (!res) return png
    } catch {}
}
exports.exeIcon = exeIcon



function exeInfo(fName, id = 0)
{
    if (Array.isArray(fName))  return fName.map((v,i) => exeInfo(v,i))
    
    const res = { id,  name: fName,  icon: extFile(fName, ['.svg', '.ico', '.webp', '.png', '.jpg', '.gif']) }
    
    try {
        res.stat = fs.statSync(fName)
        res.date = new Date(res.stat.mtime).toLocaleString()
        res.info = { FileDescription: path.parse(fName).name,   FileVersion: '',   CompanyName: '' }
        Object.assign(res.info,  winver(fName))
    }
    catch {}
    
    return res
}
exports.exeInfo = exeInfo



function exeList(dirPath, mask = '', deep = 1, result = [])
{
    const rxp = /\*exe\*[\t ]*=[\t ]*([^\*]+)/im
  
	for (const file of searchFiles(dirPath, mask, deep))
    {
        const exe = exeInfo(file, result.length),   ext = path.extname(file).toLowerCase()

        if (ext !== '.exe')
        {
            try {
                const mts = rxp.exec(fs.readFileSync(file, ext === '.lnk' ? 'utf-16le' : 'utf-8'))

                if (mts) {
                    const info = JSON.parse(mts[1]);        if (info.icon) { exe.icon = path.resolve(path.dirname(file), info.icon);    delete info.icon }
                    Object.assign(exe.info, info)
                }
            }
            catch (e) {  console.error("exeList => ", e)  }
        }

        result.push(exe)
	}
  
	return result
}
exports.exeList = exeList



function searchFiles(dirPath, mask = '', deep = 0, result = [])
{
    const rxp = new RegExp(mask, 'i'),   dir = dirPath.replace(/[\/\\]$/,'')
    
    if (deep !== true && deep >= 0)  deep--

	for (const file of readDir(dir))
    {
		const value = dir + path.sep + file;

		if (fs.statSync(value).isDirectory())   { if (deep >= 0) searchFiles(value, mask, deep, result) }
        else                                    { if (rxp.test(value)) result.push(value)               }
	}
  
	return result
}
exports.searchFiles = searchFiles



function searchDirs(dirPath, mask = '', deep = true)
{
    if (!Array.isArray(mask))  mask = [mask, '']

    const rxpFile = new RegExp(mask[0], 'i')
    const rxpDir  = new RegExp(mask[1], 'i')
    
    const dir = dirPath.replace(/[\/\\]$/,''),   files = [],   dirs = []
    
    if (deep !== true && deep >= 0)  deep--

	for (const file of readDir(dir))
    {
		const value = dir + path.sep + file

		if (fs.statSync(value).isDirectory())   { if (deep >= 0 && rxpDir.test(file)) dirs.push({ [value]: searchDirs(value, mask, deep) }) }
        else                                    { if (rxpFile.test(file)) files.push(value) }
	}
  
	return [...dirs, ...files]
}
exports.searchDirs = searchDirs



function PS(_opts)
{
    const opt = Object.assign({ exe: 'powershell.exe -NoProfile -Command ',  cwd: exports.path.ext,  time: 10000 },  _opts)

    this.run = (value, time = opt.time, exe = opt.exe) =>
    {
        const cmd = exe + value,   proc = child.spawn(cmd, [], {cwd: opt.cwd, shell: true})
        
        if (opt.debug)
        {
            proc.stdout.on("data", (v) => console.log(v.toString()))
            proc.stderr.on("data", (v) => console.log(v.toString()))
        }

        return new Promise( (resolve) =>
        {
            const tmr = (time || 0) <= 0 ? 0 : setTimeout(() => resolve(proc.exitCode), time)
            proc.on('close', () => { clearTimeout(tmr);         resolve(proc.exitCode) })
        })
    }

    this.icon  = (fn, png)      => this.run(`"Add-Type -AssemblyName System.Drawing; $I = [System.Drawing.Icon]::ExtractAssociatedIcon('${fn}'); $B = $I.ToBitmap(); $B.Save('${png}', [System.Drawing.Imaging.ImageFormat]::Png); $B.Dispose(); $I.Dispose()"`)
    this.play  = (value)        => this.run(`"&{$P=New-Object System.Media.SoundPlayer; $P.SoundLocation='${value}'; $P.playsync()}"`)
    this.speak = (value, vol)   => this.run(`"&{$V=New-Object -ComObject Sapi.spvoice; $V.volume=${vol ?? 100}; $V.rate=0; $V.speak('${value}')}"`)
    this.media = (value)        => this.run(`[System.Media.SystemSounds]::${value || 'Beep'}.Play()`)
    this.beep  = (freq, time)   => this.run(`[console]::beep(${freq || 1000},${time || 300})`)

    return this
}
exports.PS = PS